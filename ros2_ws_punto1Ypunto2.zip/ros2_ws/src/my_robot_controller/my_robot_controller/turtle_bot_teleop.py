#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sshkeyboard import listen_keyboard
from geometry_msgs.msg import Twist

# Función para ingresar un valor numérico por el usuario
def ingresar_valor(mensaje):
    while True:
        valor = input(mensaje)
        try:
            valor = float(valor)
            return valor
        except ValueError:
            print("Por favor, ingrese un valor numérico.")

# Función para generar un mensaje Twist
def generar_mensaje_twist(lineal_x, angular_z):
    twist_msg = Twist()
    twist_msg.linear.x = lineal_x
    twist_msg.angular.z = angular_z
    return twist_msg

# Función para manejar la pulsación de teclas
def tecla_pulsada(key):
    global velLin, velAng
    print(f"'{key}' pulsada")
    if key == "w":
        velLin += paramVelLin
    elif key == "s":
        velLin -= paramVelLin
    elif key == "a":
        velAng += paramVelAng
    elif key == "d":
        velAng -= paramVelAng
    else:
        print("Tecla no válida.")

    twist_msg = generar_mensaje_twist(float(velLin), float(velAng))
    publi.publish(twist_msg) 

# Función para manejar la liberación de teclas
def tecla_liberada(key):
    global velLin, velAng
    print(f"'{key}' soltada")
    if key == "w":
        velLin -= paramVelLin
    elif key == "s":
        velLin += paramVelLin
    elif key == "a":
        velAng -= paramVelAng
    elif key == "d":    
        velAng += paramVelAng
    else:
        print("Por favor, presione 'w', 's', 'a' o 'd'.")
    
    twist_msg = generar_mensaje_twist(float(velLin), float(velAng))
    publi.publish(twist_msg)

# Inicialización de ROS
rclpy.init()
node = rclpy.create_node("turtle_bot_teleop")
publi = node.create_publisher(Twist, "turtlebot_cmdVel", 10)
node.get_logger().info("Presione 'w', 's', 'a', o 'd' para mover el bot.")

# Ingresar velocidades lineal y angular
paramVelLin = ingresar_valor("Ingrese velocidad lineal: ")
paramVelAng = ingresar_valor("Ingrese velocidad angular: ")

# Inicializar velocidades lineal y angular
velLin = 0
velAng = 0

# Función principal
def main():
    listen_keyboard(
        on_press=tecla_pulsada,
        on_release=tecla_liberada,
    )

if __name__ == '__main__':
    main()
