#!/usr/bin/env python3
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_srvs.srv import Trigger

class TurtleBotPlayer(Node):

    def __init__(self):
        super().__init__('turtle_bot_player')
        self.client = self.create_client(Trigger, 'get_file_name')
        self.file_name = None  # Inicializamos file_name como None
        self.request_file_name()
        self.publisher = self.create_publisher(Twist, 'turtlebot_cmdVel', 10)
        self.timer = self.create_timer(1, self.publish_commands)

    def request_file_name(self):
        request = Trigger.Request()
        future = self.client.call_async(request)
        future.add_done_callback(self.get_file_name_callback)
        self.get_logger().info("Solicitud de nombre de archivo enviada al servicio 'get_file_name'")


    def get_file_name_callback(self, future):
        try:
            response = future.result()
            if response.success:
                self.file_name = response.message  # Asignamos el nombre del archivo al atributo file_name
                self.get_logger().info(f'Nombre del archivo recibido: {self.file_name}')
            else:
                self.get_logger().warning('No se pudo obtener el nombre del archivo.')
        except Exception as e:
            self.get_logger().error(f'Servicio "get_file_name" falló con la excepción: {str(e)}')

    def publish_commands(self):
        if self.file_name is not None:  # Verificamos que se haya recibido el nombre del archivo
            try:
                with open(self.file_name, 'r') as file:  # Abrimos el archivo recibido por el servicio
                    lines = file.readlines()  # Leer todas las líneas en una lista
                    num_lines = len(lines)  # Obtener el número total de líneas en el archivo
                    self.get_logger().info(f'Número de líneas en el archivo: {num_lines}')
                    for i, line in enumerate(lines):
                        print("Línea leída del archivo:", line.strip())  # Imprimir la línea leída del archivo

                        # Dividir la línea en los valores de velocidad lineal y angular
                        parts = line.strip().split(', ')
                        linear = float(parts[0].split(': ')[1])
                        angular = float(parts[1].split(': ')[1])

                        # Crear el mensaje Twist y publicarlo
                        twist_msg = Twist()
                        twist_msg.linear.x = linear
                        twist_msg.angular.z = angular
                        print("Velocidad lineal leída del archivo: ", linear)
                        print("Velocidad ang leída del archivo: ", angular)
                        self.publisher.publish(twist_msg)
                        time.sleep(1)
                    # Salir del método después de procesar la última línea del archivo
                    print("Fin del recorrido")
                    self.destroy_node()
                    
                    return    
            except FileNotFoundError:
                self.get_logger().error(f'Archivo no encontrado: {self.file_name}')
        else:
            self.get_logger().warning('Nombre del archivo no recibido. No se puede reproducir.')




def main(args=None):
    rclpy.init(args=args)
    node = TurtleBotPlayer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
