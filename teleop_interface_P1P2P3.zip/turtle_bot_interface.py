import os
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import messagebox

x_positions = []
y_positions = []
user_actions = []

class MyNode(Node):

    def __init__(self):
        super().__init__('my_node')
        self.subscription_cmd_vel = self.create_subscription(
            Twist,
            '/turtlebot_cmdVel',
            self.cmd_vel_callback,
            10)
        self.subscription = self.create_subscription(
            Twist,
            '/turtlebot_position',
            self.position_callback,
            10)
        plt.ion()  # Habilita el modo interactivo de matplotlib

    def position_callback(self, msg):
        # Recibe la posición
        x_position = msg.linear.x
        y_position = msg.linear.y

        x_positions.append(x_position)
        y_positions.append(y_position)

        # Actualiza la gráfica
        self.update_plot()

    def cmd_vel_callback(self, msg):
        # Registra las acciones del usuario
        user_actions.append(f"Linear: {msg.linear.x}, Angular: {msg.angular.z}")

    def update_plot(self):
        # Actualiza la gráfica con las nuevas posiciones
        plt.clf()
        plt.plot(x_positions, y_positions, marker='o', linestyle='-')
        plt.xlabel('Posición X')
        plt.ylabel('Posición Y')
        plt.title('Posición del Turtlebot2')
        plt.xlim([-2.5, 2.5])  # Límites del eje X
        plt.ylim([-2.5, 2.5])  # Límites del eje Y
        plt.grid(True)
        plt.pause(0.01)

def save_actions():
    nombre_archivo = nombre_entry.get() + '.txt'
    with open(nombre_archivo, 'w') as file:
        for action in user_actions:
            file.write(action + '\n')
    print(f"Acciones del usuario guardadas en {nombre_archivo} en el directorio actual: {os.getcwd()}")

def save_plot_and_actions():
    nombre_grafica = nombre_entry.get() + '.png'
    plt.savefig(nombre_grafica)
    print(f"Gráfica guardada como {nombre_grafica} en el directorio actual: {os.getcwd()}")
    save_actions()

def ask_save():
    guardar = messagebox.askyesno("Guardar gráfica y acciones", "¿Desea guardar la gráfica y las acciones?")
    if guardar:
        nombre_label.pack()
        nombre_entry.pack()
        guardar_button.pack()
    else:
        plt.pause(0.01)

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()

    ventana = tk.Tk()
    ventana.title("Guardar Gráfica y Acciones")

    global nombre_label, nombre_entry, guardar_button

    nombre_label = tk.Label(ventana, text="Nombre del archivo:")
    nombre_entry = tk.Entry(ventana)
    guardar_button = tk.Button(ventana, text="Guardar", command=save_plot_and_actions)

    ask_save()  # Preguntar si desea guardar antes de mostrar la entrada de texto

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

    ventana.mainloop()

if __name__ == '__main__':
    main()

