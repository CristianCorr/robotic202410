#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
import threading
import numpy as np

x_positions = []
y_positions = []

def main(args=None):
    rclpy.init(args=args)

    node = MyNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    # Aquí puedes guardar la gráfica con un nombre elegido por el usuario
    nombre_grafica = input("Ingrese un nombre para la gráfica: ")
    nombre_archivo = nombre_grafica + '.png'
    plt.savefig(nombre_archivo)

    node.destroy_node()
    rclpy.shutdown()


class MyNode(Node):

    def __init__(self):
        super().__init__('my_node')

        self.subscription = self.create_subscription(
            Twist,
            '/turtlebot_position',
            self.position_callback,
            10)

        plt.ion()  # Habilita el modo interactivo de matplotlib

        # Crear la interfaz gráfica en un hilo separado
        self.thread = threading.Thread(target=self.create_gui)
        self.thread.start()

    def position_callback(self, msg):
        # Recibe la posicion
        x_position = msg.linear.x
        y_position = msg.linear.y

        x_positions.append(x_position)
        y_positions.append(y_position)

        # Actualiza grafica
        self.update_plot()

    def update_plot(self):
        # Actualiza la gráfica con las nuevas posiciones
        plt.clf()
        plt.plot(x_positions, y_positions)
        plt.xlabel('Posición X')
        plt.ylabel('Posición Y')
        plt.title('Posición del Turtlebot2')
        plt.xlim([-2.5, 2.5])  # Límites del eje X
        plt.ylim([-2.5, 2.5])  # Límites del eje Y
        plt.grid(True)
        plt.pause(0.01)

    def create_gui(self):
        ventana = tk.Tk()
        ventana.title("Interfaz gráfica con Matplotlib en ROS 2")

        fig, ax = plt.subplots()

        # Ejemplo de gráfico: una curva seno
        x = np.linspace(0, 10, 100)
        y = np.sin(x)
        ax.plot(x, y)

        # Convertir la figura a un widget de Tkinter
        canvas = FigureCanvasTkAgg(fig, master=ventana)

        # Ajustar el tamaño del widget
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        ventana.mainloop()

if __name__ == '__main__':
    main()
